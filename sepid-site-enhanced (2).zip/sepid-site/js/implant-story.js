/* Four-stage implant story. The assembled reference is visible on entry; each gesture advances exactly one stage. */
const section = document.querySelector('#implant-story');

if (section) {
  const $ = selector => section.querySelector(selector);
  const $$ = selector => [...section.querySelectorAll(selector)];
  const visual = $('.implant-visual');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const shortScreen = matchMedia('(max-height: 520px)');
  const copies = $$('.implant-copy');
  const dots = $$('.implant-rail button');
  const counter = $('[data-current]');
  const note = $('.implant-note');
  const digits = ['۱', '۲', '۳', '۴'];
  const LAST_STAGE = 3;
  const WHEEL_GESTURE_IDLE = 125;
  const CENTER = 500;
  const EPSILON = .001;
  const viewStates = [
    { scale: 1.000, x: 0, y: 0 },
    { scale: 1.018, x: -3, y: -2 },
    { scale: 1.000, x: 0, y: 0 },
    { scale: 1.000, x: 0, y: 0 }
  ];
  const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
  const ease = n => {
    n = clamp(n);
    return n < .5 ? 4 * n * n * n : 1 - Math.pow(-2 * n + 2, 3) / 2;
  };

  let enabled = false;
  let broken = false;
  let locked = false;
  let completed = false;
  let entered = false;
  let targetProgress = 0;
  let currentProgress = 0;
  let activeStage = -1;
  let lastDirection = 0;
  let raf = 0;
  let lastFrameTime = 0;
  let wheelGestureActive = false;
  let wheelTimer = 0;
  let touch = null;
  let touchHandled = false;
  let scene = null;
  let frames = [];
  let finalWordmark = null;

  function viewTransform(state, zoomDelta = 0, xDelta = 0, yDelta = 0) {
    const scale = state.scale + zoomDelta;
    const x = CENTER * (1 - scale) + state.x + xDelta;
    const y = CENTER * (1 - scale) + state.y + yDelta;
    return `translate(${x.toFixed(2)} ${y.toFixed(2)}) scale(${scale.toFixed(4)})`;
  }

  function paint(progress) {
    if (!scene || !frames.length) return;
    const position = clamp(progress) * LAST_STAGE;
    const from = Math.min(LAST_STAGE, Math.floor(position));
    const to = Math.min(LAST_STAGE, from + 1);
    const local = from === to ? 0 : position - from;
    const blend = ease(local);

    frames.forEach((node, i) => {
      let opacity = 0;
      let state = viewStates[i];
      let zoomDelta = 0;
      let yDelta = 0;
      if (from === to && i === from) {
        opacity = 1;
      } else if (i === from) {
        opacity = 1 - blend;
        state = viewStates[from];
        zoomDelta = -.012 * blend;
        yDelta = -3 * blend;
      } else if (i === to) {
        opacity = blend;
        state = viewStates[to];
        zoomDelta = -.018 * (1 - blend);
        yDelta = 5 * (1 - blend);
      }
      node.setAttribute('opacity', opacity.toFixed(4));
      node.setAttribute('transform', viewTransform(state, zoomDelta, 0, yDelta));
      node.setAttribute('aria-hidden', opacity > .5 ? 'false' : 'true');
    });

    if (finalWordmark) {
      const wordIn = ease(clamp((position - 2.34) / .66));
      finalWordmark.setAttribute('opacity', wordIn.toFixed(4));
      finalWordmark.setAttribute('transform', `translate(0 ${(-26 * (1 - wordIn)).toFixed(1)})`);
    }

    copies.forEach((node, i) => {
      let alpha = 0;
      if (from === to && i === from) alpha = 1;
      else if (i === from) alpha = 1 - blend;
      else if (i === to) alpha = blend;
      const y = i === from && from !== to ? -14 * blend : 22 * (1 - alpha);
      node.style.opacity = alpha.toFixed(3);
      node.style.transform = `translate3d(0, ${y.toFixed(1)}px, 0)`;
      node.setAttribute('aria-hidden', i === Math.round(position) ? 'false' : 'true');
    });
  }

  function updateControls(progress = currentProgress) {
    const stage = Math.round(clamp(progress) * LAST_STAGE);
    if (stage !== activeStage) {
      activeStage = stage;
      counter.textContent = digits[stage];
      dots.forEach((dot, i) => {
        if (i === stage) dot.setAttribute('aria-current', 'step');
        else dot.removeAttribute('aria-current');
      });
    }
    dots.forEach(dot => { dot.disabled = completed; });
    section.classList.toggle('is-complete', completed);
    if (note) note.setAttribute('aria-hidden', completed ? 'true' : 'false');
  }

  function requestFrame() {
    if (!raf && !document.hidden) raf = requestAnimationFrame(tick);
  }

  function finishOnce() {
    if (completed) return;
    completed = true;
    locked = false;
    targetProgress = currentProgress = 1;
    paint(1);
    updateControls(1);
  }

  function tick(now) {
    raf = 0;
    if (document.hidden || !scene) return;
    const dt = lastFrameTime ? Math.max(1, now - lastFrameTime) : 16.67;
    lastFrameTime = now;
    const alpha = 1 - Math.exp(-dt / 72);
    currentProgress += (targetProgress - currentProgress) * alpha;
    if (Math.abs(targetProgress - currentProgress) < .00035) currentProgress = targetProgress;
    currentProgress = clamp(currentProgress);
    paint(currentProgress);
    updateControls(currentProgress);

    if (!completed && locked && targetProgress >= 1 - EPSILON && currentProgress >= 1 - EPSILON) {
      finishOnce();
    } else if (locked && lastDirection < 0 && targetProgress <= EPSILON && currentProgress <= EPSILON) {
      locked = false;
    }

    if (Math.abs(targetProgress - currentProgress) > .00035) raf = requestAnimationFrame(tick);
    else lastFrameTime = 0;
  }

  function bounds() {
    const rect = section.getBoundingClientRect();
    return { top: rect.top + scrollY, bottom: rect.bottom + scrollY };
  }

  function scrollToStoryTop() {
    const top = bounds().top;
    if (Math.abs(scrollY - top) < 2) return;
    const html = document.documentElement;
    const previous = html.style.scrollBehavior;
    html.style.scrollBehavior = 'auto';
    scrollTo(0, Math.max(0, Math.round(top)));
    html.style.scrollBehavior = previous;
  }

  function begin(direction = 1) {
    if (!enabled || !scene || completed) return false;
    locked = true;
    lastDirection = direction;
    if (!entered) {
      entered = true;
      currentProgress = targetProgress = 0;
      visual.classList.add('is-arriving');
      paint(0);
      updateControls(0);
    }
    scrollToStoryTop();
    return true;
  }

  function inStoryViewport() {
    const rect = section.getBoundingClientRect();
    return rect.top < innerHeight * .82 && rect.bottom > innerHeight * .18;
  }

  function isInteractive(target) {
    return target instanceof Element && !!target.closest('input, textarea, select, button, a, summary, [contenteditable="true"], dialog[open]');
  }

  function isFormControl(target) {
    return target instanceof Element && !!target.closest('input, textarea, select, [contenteditable="true"], dialog[open]');
  }

  function keepWheelGestureLocked() {
    wheelGestureActive = true;
    clearTimeout(wheelTimer);
    wheelTimer = setTimeout(() => { wheelGestureActive = false; }, WHEEL_GESTURE_IDLE);
  }

  function stepByGesture(direction) {
    if (!locked || completed || !direction) return false;
    lastDirection = direction;
    const stage = Math.round(clamp(targetProgress) * LAST_STAGE);
    const next = stage + direction;
    if (next < 0) {
      locked = false;
      return false;
    }
    if (next > LAST_STAGE) return true;
    targetProgress = next / LAST_STAGE;
    requestFrame();
    return true;
  }

  function onWheel(event) {
    if (!enabled || !scene || completed || isFormControl(event.target) || event.ctrlKey) return;
    const scale = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? innerHeight : 1;
    const delta = event.deltaY * scale;
    if (!delta) return;
    const direction = Math.sign(delta);

    if (!locked) {
      const page = bounds();
      const y = scrollY;
      const inside = y >= page.top && y < page.bottom;
      const crossing = direction > 0
        ? y < page.top && y + Math.max(1, delta) >= page.top - 10
        : y >= page.bottom && y + Math.min(-1, delta) <= page.bottom + 10;
      if (!inside && !crossing) return;
      const firstEntry = !entered;
      if (!begin(direction)) return;
      if (firstEntry) {
        keepWheelGestureLocked();
        event.preventDefault();
        return;
      }
    }

    if (wheelGestureActive) {
      keepWheelGestureLocked();
      event.preventDefault();
      return;
    }
    keepWheelGestureLocked();
    if (stepByGesture(direction)) event.preventDefault();
  }

  function onKey(event) {
    if (!enabled || !scene || completed || isInteractive(event.target) || event.altKey || event.ctrlKey || event.metaKey || event.repeat) return;
    let direction = 0;
    if (event.key === 'ArrowDown' || event.key === 'PageDown' || event.code === 'Space' && !event.shiftKey) direction = 1;
    else if (event.key === 'ArrowUp' || event.key === 'PageUp' || event.code === 'Space' && event.shiftKey) direction = -1;
    if (!direction) return;

    if (!locked) {
      if (direction < 0 && entered && currentProgress <= EPSILON) return;
      if (!inStoryViewport() || !begin(direction)) return;
      event.preventDefault();
      return;
    }
    if (stepByGesture(direction)) event.preventDefault();
  }

  function onTouchStart(event) {
    if (event.touches.length !== 1) { touch = null; touchHandled = false; return; }
    touch = { y: event.touches[0].clientY };
    touchHandled = false;
  }

  function onTouchMove(event) {
    if (!enabled || !scene || completed || !touch || touchHandled || event.touches.length !== 1 || isFormControl(event.target)) return;
    const y = event.touches[0].clientY;
    const delta = touch.y - y;
    touch.y = y;
    if (Math.abs(delta) < 1) return;
    const direction = Math.sign(delta);

    if (!locked) {
      if (direction < 0 && entered && currentProgress <= EPSILON) return;
      if (!inStoryViewport() || !begin(direction)) return;
      touchHandled = true;
      event.preventDefault();
      return;
    }
    touchHandled = true;
    if (stepByGesture(direction)) event.preventDefault();
  }

  function onTouchEnd() { touch = null; touchHandled = false; }

  function syncMotionMode() {
    enabled = !reduced.matches && !shortScreen.matches && !broken;
    section.classList.toggle('is-enhanced', enabled);
    if (!enabled) {
      locked = false;
      cancelAnimationFrame(raf);
      raf = 0;
      lastFrameTime = 0;
    } else if (scene) {
      paint(currentProgress);
      updateControls(currentProgress);
    }
  }

  dots.forEach(dot => dot.addEventListener('click', () => {
    if (!enabled || !scene || completed) return;
    if (!locked) {
      if (!inStoryViewport() || !begin(1)) return;
    }
    const destination = Number(dot.dataset.step) / LAST_STAGE;
    lastDirection = Math.sign(destination - currentProgress);
    targetProgress = destination;
    requestFrame();
  }));

  document.addEventListener('wheel', onWheel, { passive: false, capture: true });
  document.addEventListener('keydown', onKey, true);
  document.addEventListener('touchstart', onTouchStart, { passive: true, capture: true });
  document.addEventListener('touchmove', onTouchMove, { passive: false, capture: true });
  document.addEventListener('touchend', onTouchEnd, { passive: true, capture: true });
  document.addEventListener('touchcancel', onTouchEnd, { passive: true, capture: true });
  window.addEventListener('resize', () => {
    if (enabled && locked) scrollToStoryTop();
  }, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      cancelAnimationFrame(raf);
      raf = 0;
      lastFrameTime = 0;
    } else if (Math.abs(targetProgress - currentProgress) > .00035) requestFrame();
  });
  reduced.addEventListener('change', syncMotionMode);
  shortScreen.addEventListener('change', syncMotionMode);

  syncMotionMode();

  async function loadReferenceScene() {
    const response = await fetch(new URL('../assets/implant/implant-scene.svg', import.meta.url));
    if (!response.ok) throw new Error(`SVG stage HTTP ${response.status}`);
    const text = await response.text();
    const parsed = new DOMParser().parseFromString(text, 'image/svg+xml');
    if (parsed.querySelector('parsererror')) throw new Error('SVG parse error');

    const root = parsed.documentElement;
    const images = [...root.querySelectorAll('image')];
    if (!images.length) throw new Error('SVG stage contains no reference images');
    await Promise.all(images.map(image => new Promise((resolve, reject) => {
      const href = image.getAttribute('href') || image.getAttributeNS('http://www.w3.org/1999/xlink', 'href');
      if (!href) return reject(new Error('Reference image has no href'));
      const preload = new Image();
      preload.onload = resolve;
      preload.onerror = () => reject(new Error(`Could not load ${href}`));
      preload.src = new URL(href, document.baseURI).href;
      if (preload.complete && preload.naturalWidth) resolve();
    })));

    scene = document.importNode(root, true);
    scene.classList.add('implant-photo-scene');
    visual.replaceChildren(scene);
    frames = [...scene.querySelectorAll('[data-photo-frame]')];
    finalWordmark = scene.querySelector('#final-wordmark');
    if (frames.length !== 4 || !finalWordmark) throw new Error('Missing SVG story layers');
    scene.setAttribute('aria-hidden', 'true');
    paint(currentProgress);
    updateControls(currentProgress);

    if ('IntersectionObserver' in window) {
      const entryObserver = new IntersectionObserver(entries => {
        if (!enabled || !scene || entered || completed) return;
        if (entries.some(entry => entry.isIntersecting)) begin(1);
      }, { threshold: .25, rootMargin: '0px 0px -14% 0px' });
      entryObserver.observe(section);
    }
  }

  loadReferenceScene().catch(error => {
    broken = true;
    locked = false;
    syncMotionMode();
    console.error('Implant photo story unavailable:', error);
  });
}
